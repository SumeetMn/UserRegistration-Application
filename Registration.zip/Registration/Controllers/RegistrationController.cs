﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Registration.DBContext;
using Registration.Models;

namespace Registration.Controllers
{
    public class RegistrationController : Controller
    {
        private readonly RegistrationCrudContext _context;
        private readonly IWebHostEnvironment _env;
        public RegistrationController(RegistrationCrudContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }
        public IActionResult getState() 
        {
            var states = _context.States.ToList();
            return Json(states);
        }
        public IActionResult getCities(string stateID)
        {
            var cities = _context.Cities.Where(x=>x.StateId==Convert.ToInt32(stateID)).ToList();
            return Json(cities);
        }
        public IActionResult Registration() => View(new UserDetail());
        [HttpPost]
        public async Task<IActionResult> Registration(UserDetail userDetail, IFormFile Photo, IFormCollection form)
        {
            if (form != null && !string.IsNullOrEmpty(form["Gender"].ToString()))
            {
                userDetail.Gender = form["Gender"].ToString();
            }

            if (Photo != null)
            {
                var ext = Path.GetExtension(Photo.FileName);

                if (ext != ".jpg" && ext != ".png")
                    ModelState.AddModelError("Photo", "Only .jpg and .png allowed");

                try
                {
                    var path = Path.Combine(_env.WebRootPath, "uploads", Photo.FileName);
                    DirectoryInfo directoryInfo = new DirectoryInfo(path);
                    if (!Directory.Exists(directoryInfo.FullName))
                    {
                        Directory.CreateDirectory(path);
                    }
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await Photo.CopyToAsync(stream);
                    }
                }
                catch { }
                userDetail.PhotoPath = "/uploads/" + Photo.FileName;
            }

            if (!ModelState.IsValid)
                return View(userDetail);

            _context.UserDetails.Add(userDetail);
            _context.SaveChanges();
            return RedirectToAction("GetAllUser");
        }

        public IActionResult GetAllUser()
        {
            List<Users> lstusers = new List<Users>();
            if (TempData["FilteredUsers"] != null)
            {
                lstusers = JsonConvert.DeserializeObject<List<Users>>(TempData["FilteredUsers"].ToString());
                return View(lstusers);
            }
            List<UserDetail> lstuserDetail = new List<UserDetail>();
            lstuserDetail = _context.UserDetails.ToList();
            getUsers(lstusers, lstuserDetail);
            return View(lstusers);
        }
        [HttpPost]
        public IActionResult GetAllUserFilter(List<Users> users)
        {
            List<Users> lstusers = new List<Users>();
            List<UserDetail> lstuserDetail = new List<UserDetail>();
            if (users != null && users.Count>0 && (!string.IsNullOrEmpty(users[0].FilterName) || !string.IsNullOrEmpty(users[0].FilterState)
                || !string.IsNullOrEmpty(users[0].FilterGender)))
            {
                lstuserDetail = _context.UserDetails.Where(x => x.Name.Contains(users[0].FilterName)
                || x.State == Convert.ToInt16(users[0].FilterState)
                || x.Gender == users[0].FilterGender).ToList();
                getUsers(lstusers, lstuserDetail);
            }
            TempData["FilteredUsers"] = JsonConvert.SerializeObject(lstusers);
            return RedirectToAction("GetAllUser", new { user = lstusers });
        }

        private void getUsers(List<Users> lstusers, List<UserDetail> lstuserDetail)
        {
            foreach(var userD in lstuserDetail)
            {
                lstusers.Add(new Users
                {
                    Name = userD.Name,
                    Gender = userD.Gender,
                    State = Convert.ToInt16(userD.State),
                    Email= userD.Email,
                    PhotoPath= userD.PhotoPath,
                    Dob=userD.Dob,
                    Contact=userD.Contact,
                    Phone=userD.Phone,
                    City=userD.City,
                    Hobbies=userD.Hobbies
                });
            }
        }
    }
}
