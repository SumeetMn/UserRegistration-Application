﻿$(document).ready(function ()
{
    $("#result").hide();
    $("#resultContact").hide();
    $.get("/Registration/getState", function (data) {
        $.each(data, function (i, item) {
            $('#State').append(`<option value="${item.stateId}">${item.stateName}</option>`);
        });
    });

    $('#State').change(function ()
    {
        debugger;
        var stateID = $(this).val();
        $('#City').empty().append('<option>Select City</option>');
        $.get("/Registration/getCities?stateID=" + stateID, function (data) {
            debugger;
            $.each(data, function (i, item) {
                $('#City').append(`<option value="${item.cityId}">${item.cityName}</option>`);
            });
        });
    });

    $('#registrationForm').submit(function (e)
    {
        $("#result").hide();
        $("#resultContact").hide();
        var email = $("#emailID").val();
        var pattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!pattern.test(email))
        {
            $("#result").show();
            $("#result").text("Invalid email").css("color", "red");
            e.preventDefault();
            return false;
        }

        const contact = $('#txtcontact').val();
        const phone = $('#txtphone').val();
        if (contact == "" || contact == undefined)
        {
            if (phone == "" || phone == undefined) {
                $("#resultContact").show();
                $("#resultContact").text("Contact or phone must be required").css("color", "red");
                e.preventDefault();
                return false;
            }
        }

        if (!$('#termsCheckbox').is(':checked')) {
            alert('You must agree to terms.');
            e.preventDefault();
            return false;
        }
    });
});