﻿using System.ComponentModel.DataAnnotations;

namespace Registration.DBContext;

public partial class UserDetail
{
    public int UserId { get; set; }
    [Required]
    [MaxLength(25)]
    public string? Name { get; set; }
    [Required]
    public string? Gender { get; set; }

    public DateTime? Dob { get; set; }

    public string? Email { get; set; }

    public string? Contact { get; set; }

    public string? Phone { get; set; }

    public int? State { get; set; }

    public int? City { get; set; }

    public string? Hobbies { get; set; }

    public string? PhotoPath { get; set; }
}
