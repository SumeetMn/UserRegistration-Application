﻿using System;
using System.Collections.Generic;

namespace Registration.DBContext;

public partial class State
{
    public int StateId { get; set; }

    public string? StateName { get; set; }
}
